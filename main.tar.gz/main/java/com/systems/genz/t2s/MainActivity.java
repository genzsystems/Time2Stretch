package com.systems.genz.t2s;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.PopupWindow;

/// Main routine sets up initial UI
// Services task will do most of the work
// Such as t2s_alert will handle the random "Stretch" popup boxes
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Run_Bkgnd;
        NumberPicker numberPicker;


        // set min and max timeout. move to taskmgr
        numberPicker = (NumberPicker) findViewById(R.id.numberPicker);

        Run_Bkgnd = (Button) findViewById(R.id.button);
        // set min and max timeout. move to taskmgr
        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(10);
        numberPicker.setValue(5);
        // Begin Experimental PopUp with submit button. Move to Alert once working
        // Experimental popup button. move this to alert when done
        final Button btnOpenPopup = (Button) findViewById(R.id.openpopup);

        btnOpenPopup.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View V) {
// what does this do?
                LayoutInflater layoutInflater
                        = (LayoutInflater) getBaseContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
// what does this do?
                View popupView = layoutInflater.inflate(R.layout.popup, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                // What does this do?
                Button btnDismiss = (Button) popupView.findViewById(R.id.dismiss);
// What does this do?
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });
                // what does this do?
                popupWindow.showAsDropDown(btnOpenPopup, 50, -30);
            }
        });
        // End Experimental Popup code
        // Handles Submit Button
        Run_Bkgnd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //move app to background
                moveTaskToBack(true);
            }
        });
    }

    // Method to start the service
    public void startService(View view) {
        startService(new Intent(getBaseContext(), t2s_taskmgr.class));
    }

    // Method to stop the service
    public void stopService(View view) {
        stopService(new Intent(getBaseContext(), t2s_taskmgr.class));
    }
}
