package com.systems.genz.t2s;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;

/**
 * Created by alex on 9/26/16.
 * Taskmgr haneles following service requests:
 * - enable or disable application
 * - Timeout adjustments. Values in minutes
 * - Starting, Stopping and Restarting the application
 */

public class t2s_taskmgr extends Service {

    // local static variables
    private final int defaultValue = 5;
    // Define task states
    private enum TaskState {
        TASK_START,
        TASK_STOP,
        TASK_RESUME,
        TASK_PAUSE
    }

    // TimeToStretch is enabled by default. timeout is 5 minutes by default and app
    // is stopped.
    boolean enableT2S = true;
    int timeoutMins = defaultValue;
    TaskState taskStatus = TaskState.TASK_STOP;


    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Let it continue running until it is stopped.
        Toast.makeText(this, "T2S Taskmgr Service Started", Toast.LENGTH_LONG).show();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "T2S Alert Service Destroyed", Toast.LENGTH_LONG).show();
    }

    // Enable T2S App. All services active. allows Start,Stop,Pause and Resume
    private void enableT2S () {
        enableT2S = true;
    }
    // Disable T2S app. All services disabled. Disabled all actions like Start
    private void disableT2S () {
        enableT2S = false;
    }
    // Change timeout value per users request. Range 1 to 10 minutes
    private void setTimeout (int newTimeoutMins) {
        timeoutMins = newTimeoutMins;
    }
    // start application. This causes the applicaiton to run from beginnning
    private void startApp() {
        //starts T2S
        taskStatus = TaskState.TASK_START;
    }
    // stop the application. Unload from memory and clean up
    private void stopApp() {
        // stops T2S
        taskStatus = TaskState.TASK_STOP;
    }
    // Pause app. Doesn't unload from memory or clean up resources
    private void pauseApp() {
        // pauses T2S
        taskStatus = TaskState.TASK_PAUSE;
    }
    // Restarts app that has resources in memory
    private void resumeApp() {
        // resumes T2S
        taskStatus = TaskState.TASK_RESUME;
    }
}
