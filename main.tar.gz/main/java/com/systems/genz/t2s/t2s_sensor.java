package com.systems.genz.t2s;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;
/**
 * Created by alex on 9/26/16.
 * T2S Sensor Service has several analytics that monitor the position of the
 * smartphone. Details of the different analytics:
 * Pitch - monitors the pitch angle of the smartphone
 * Roll - monitors the roll angle of the smartphone
 * Yaw - monitors the yaw movement of the smartphone
 * Proximity - hook for future support
 * Timer - Tracks minutes the smartphone is put into a specific position
 *
 * How it works:
 * The timer is set to 0 minutes and will not increment until the following occurs:
 *     -> Pitch angle position of phone is 45 +/- 10 degrees
 *     -> Roll angle position of phone is 0 +/- 5 degrees
 *     -> Yaw position of phone is 0 +/- 5 degrees
 * If phone falls into all parameters, a timer begins to increment and a cumulative value
 * is tracked i.e. if the user puts phone in the position parameters for 1 minute, then
 * 1 minute is stored in a cumulative variable. Once phone hits max timeout value, a message is
 * sent to the Alert Service. The Alert Service will display a simple popup message to alert
 * the user to stretch their neck.
 */
public class t2s_sensor extends Service{
    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Let it continue running until it is stopped.
        Toast.makeText(this, "T2S Sensor Service Started", Toast.LENGTH_LONG).show();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "T2S Sensor Service Destroyed", Toast.LENGTH_LONG).show();
    }

    private void trackPitch () {
        // track phone pitch angle
    }

    private void trackRoll () {
        // track phone roll angle
    }

    private void trackYaw () {
        // track phone yaw position
    }

    private void incrementCounter () {
        // increment counter variable
    }

    private void pauseCounter() {
        // Pause counter
    }

    private void resumeCounter() {
        // Resume counter
    }

    private void resetCounter () {
        // Reset counter to 0 minutes
    }

    private void triggerAlert () {
        // send message to Alert Service that cumulative timer
        // has exceeded max timeout value (1 to 10 minutes with
        // 5 minute as default
    }
}
