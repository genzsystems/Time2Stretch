package com.systems.genz.t2s;

/**
 * Created by alex on 9/26/16.
 * Hooks for future utilities
 */
public class t2s_utils {
}
