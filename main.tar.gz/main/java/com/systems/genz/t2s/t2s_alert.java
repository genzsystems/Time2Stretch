package com.systems.genz.t2s;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.Toast;

/**
 * Created by alex on 9/26/16.
 * T2S Alert Service displays a pop up alert screen that tells user to
 * stretch their neck. The user then hits OK button to reset service.
 * Alert Service pop up is triggered by message from T2S Sensor service
 */
public class t2s_alert extends Service {

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Let it continue running until it is stopped.
        Toast.makeText(this, "T2S Alert Service Started", Toast.LENGTH_LONG).show();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "T2S Alert Service Destroyed", Toast.LENGTH_LONG).show();
    }

    private void displayPopup() {
        // Display Popup message using random images

   /*     // Begin Experimental PopUp with submit button. Move to Alert once working
        // Experimental popup button. move this to alert when done
        final Button btnOpenPopup = (Button) findViewById(R.id.openpopup);

        btnOpenPopup.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View V) {
// what does this do?
                LayoutInflater layoutInflater
                        = (LayoutInflater) getBaseContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
// what does this do?
                View popupView = layoutInflater.inflate(R.layout.popup, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                // What does this do?
                Button btnDismiss = (Button) popupView.findViewById(R.id.dismiss);
// What does this do?
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });
                // what does this do?
                popupWindow.showAsDropDown(btnOpenPopup, 50, -30);
            }
        });
        // End Experimental Popup code*/
    }

    private void resetPopup() {
        // Reset popup based on user input
    }
}
