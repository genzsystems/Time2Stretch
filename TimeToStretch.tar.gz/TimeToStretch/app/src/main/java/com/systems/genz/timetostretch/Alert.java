package com.systems.genz.timetostretch;

/**
 * Created by alex on 9/11/16.
 */
public class Alert {
}
